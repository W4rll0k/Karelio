import { useEffect, useId, useRef, useState } from 'react';
import { Check, ImagePlus, RotateCcw, X, SlidersHorizontal } from 'lucide-react';
import { readLogo } from '../lib/qr';
const palettes = [
    { name: 'Klasik', fg: '#172033', bg: '#ffffff' }, { name: 'Kobalt', fg: '#315cf5', bg: '#ffffff' },
    { name: 'Orman', fg: '#17584b', bg: '#f1f7f0' }, { name: 'Lavanta', fg: '#65439a', bg: '#f5f0ff' },
    { name: 'Vişne', fg: '#8d2948', bg: '#fff2f5' }, { name: 'Toprak', fg: '#8a452c', bg: '#fff5e9' },
];
function ColorField({ label, value, onChange }) {
    const id = useId();
    const [draft, setDraft] = useState(value);
    const [editing, setEditing] = useState(false);
    const shown = editing ? draft : value;
    const error = editing && !/^#[0-9a-f]{6}$/i.test(draft);
    return <div className="field"><label htmlFor={id}>{label}</label><div className="color-field"><input type="color" aria-label={`${label} seç`} value={value} onChange={e => { onChange(e.target.value); setDraft(e.target.value); }}/><input id={id} type="text" aria-label={`${label} HEX kodu`} spellCheck={false} value={shown.toUpperCase()} maxLength={7} onFocus={() => { setEditing(true); setDraft(value); }} onChange={e => { setDraft(e.target.value); if (/^#[0-9a-f]{6}$/i.test(e.target.value))
        onChange(e.target.value); }} onBlur={() => { setEditing(false); setDraft(value); }} aria-invalid={error} aria-describedby={error ? `${id}-error` : undefined}/></div>{error && <p id={`${id}-error`} className="field-error">#123ABC biçiminde 6 haneli renk gir.</p>}</div>;
}
export default function DesignControls({ design, onChange, onReset, notify }) {
    const [logoError, setLogoError] = useState('');
    const [loading, setLoading] = useState(false);
    const upload = useRef(null);
    const request = useRef(0);
    useEffect(() => () => { request.current++; }, []);
    return <section className="panel design-panel" aria-labelledby="design-heading"><div className="section-heading"><div className="section-title"><span className="step-number">02</span><h2 id="design-heading">Tasarımını özelleştir</h2></div><button className="text-button reset-design" onClick={() => { request.current++; setLoading(false); setLogoError(''); onReset(); }}><RotateCcw size={14}/><span>Tasarımı sıfırla</span></button></div><div className="design-body"><div className="form-row color-row"><ColorField label="QR rengi" value={design.foreground} onChange={foreground => onChange({ foreground })}/><ColorField label="Arka plan" value={design.background} onChange={background => onChange({ background })}/></div><div className="palette-row"><span className="small-label">Hazır paletler</span><div className="palettes">{palettes.map(p => <button key={p.name} className="palette" aria-label={`${p.name} renk paleti`} aria-pressed={design.foreground.toLowerCase() === p.fg && design.background.toLowerCase() === p.bg} title={p.name} onClick={() => onChange({ foreground: p.fg, background: p.bg })} style={{ background: p.bg, color: p.fg }}><span style={{ background: p.fg }}>{design.foreground.toLowerCase() === p.fg && design.background.toLowerCase() === p.bg && <Check size={13}/>}</span></button>)}</div></div><div className="design-divider"/><div className="form-row"><fieldset className="style-field"><legend>Nokta stili</legend><div className="segmented">{['square', 'rounded'].map(style => <button key={style} aria-pressed={design.dots === style} onClick={() => onChange({ dots: style })}><span className={`dot-style ${style}`}><i /><i /><i /><i /></span>{style === 'square' ? 'Kare' : 'Yuvarlak'}</button>)}</div></fieldset><fieldset className="style-field"><legend>Köşe stili</legend><div className="segmented">{['square', 'rounded'].map(style => <button key={style} aria-pressed={design.corners === style} onClick={() => onChange({ corners: style })}><span className={`corner-style ${style}`}/>{style === 'square' ? 'Kare' : 'Yumuşak'}</button>)}</div></fieldset></div><div className="logo-heading"><span className="small-label">Kendi logonu ekle</span><span className="optional-tag">İsteğe bağlı</span></div><input ref={upload} type="file" accept="image/png,image/jpeg,image/webp" className="sr-only" aria-label="Logo dosyası seç" tabIndex={-1} onChange={async (e) => { const file = e.target.files?.[0]; e.target.value = ''; if (!file)
        return; const token = ++request.current; setLoading(true); setLogoError(''); try {
        const logo = await readLogo(file);
        if (token === request.current) {
            onChange({ logo });
            notify('Logo eklendi.');
        }
    }
    catch (err) {
        if (token === request.current)
            setLogoError(err instanceof Error ? err.message : 'Logo yüklenemedi.');
    }
    finally {
        if (token === request.current)
            setLoading(false);
    } }}/>{design.logo ? <div className="uploaded-logo"><img src={design.logo} alt="Yüklenen logo"/><div><strong>Logon hazır</strong><span>Yüksek hata düzeltme etkin</span></div><button className="icon-button" aria-label="Logoyu kaldır" onClick={() => { request.current++; onChange({ logo: null }); setLogoError(''); }}><X size={18}/></button></div> : <button className="upload-zone" disabled={loading} onClick={() => upload.current?.click()}><span className="upload-icon"><ImagePlus size={20}/></span><span><strong>{loading ? 'Logo hazırlanıyor…' : 'Logo yüklemek için seç'}</strong><small>PNG, JPG veya WebP · En fazla 2 MB</small></span></button>}{logoError && <p className="field-error" role="alert">{logoError}</p>}{design.logo && <div className="logo-scale"><label htmlFor="logo-scale">Logo boyutu <span>%{Math.round(design.logoScale * 100)}</span></label><input id="logo-scale" type="range" min="10" max="18" value={Math.round(design.logoScale * 100)} onChange={e => onChange({ logoScale: Number(e.target.value) / 100 })}/><p className="field-hint">Okunabilirliği korumak için logo alanı sınırlıdır. Paylaşmadan önce telefonunla tara.</p></div>}<div className="design-footnote"><SlidersHorizontal size={14}/> Değişiklikler önizlemene otomatik uygulanır.</div></div></section>;
}
